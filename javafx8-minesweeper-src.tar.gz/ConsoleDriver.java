public class ConsoleDriver {
	public static void main(String[] args) {
		MinesweeperConsoleController cc = new MinesweeperConsoleController (10, 10, 10);
		cc.run();
	}
}
